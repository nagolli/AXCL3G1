/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_arc;

import java.io.BufferedReader;
//import java.io.DataInputStream;
//import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;


/**
 *
 * @author aline
 */
public class Cliente extends Thread {
    
   private static int PUERTO;
   private static Socket cliente;
   private static InetAddress address;
   private static String host;
   private static String grupos;
   private static vistaCliente cv;
  
  public Cliente()
  {
       PUERTO = 3;
       cliente = null;
       address = null;
       host ="localhost";
  }
  
  
  public void Conectar() 
    {
        try
        {
            //Determina la IP del host, mediante el nombre del host
            address = InetAddress.getByName(host);
            //Mostramos por pantalla si se conecta o no al servidor
            System.out.println("Conectandose al servidor...");
            /**
             * Inicializamos la variable cliente como un nuevo socket donde 
             * tendremos la información de la dirección IP y el puerto.
             */
            cliente = new Socket(address,PUERTO);
            //Mostramos la dirección que se ha almacenado en "address".
            System.out.println("Conectandose al cliente " + cliente.getRemoteSocketAddress());
        }
        /**
         * Si el host no es conocido mostrara por pantalla  que se desconoce 
         * el host.
         */
        catch(UnknownHostException h)
        {
            System.out.println("Host no conocido");
        }
        /**
         * En este caso usamos err,en vez de out, para desplegar un mensaje de 
         * error y nos indica que la IP no es valida o el puerto no es válido
         */
        catch (IOException e)
        {
            System.err.println("IOException" + e); 
        }
    }
  
   /**
     * Terminamos la conexión que habiamos iniciado.
     */
   public void Desconectar()
    {
        // Intentamos desconectarnos en caso de que el servidor no lo haya hecho
        try
        {
            cliente.close();
        }
        // Error, si el servidor ha desconectado al cliente.
        catch(IOException e)
        {
            System.err.println("IOException " + e);
        }
    }
      
   
   // Envia al Servidor el número de grupo seleccionado
    public void enviarGrupoServidor(int n_grupo)
    {
        System.out.println("Grupo "+n_grupo +" seleccionado. Enviando información al servidor...");
    }
    
    // Función que guarda los grupos disponibles que le ha pasado el servidor
    public static void setGruposDisponibles(String grupos)
    {
        grupos = grupos; 
        System.out.println("g"+grupos);
    }
    
    // Función que devuelve los grupos disponibles
    public String getGruposDisponibles()
    {
        return this.grupos;
    }
    
   
}
    
    
    
    
    


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto_arc;

/**
 *
 * @author aline
 */
public class proyectoARC {
    
    
    public static void main(String[] args)
    {
        Cliente cliente = new Cliente();
        vistaCliente vistaCliente = new vistaCliente(cliente);
        
      // vistaCliente.setVisible(true);
        
    }
    
}
